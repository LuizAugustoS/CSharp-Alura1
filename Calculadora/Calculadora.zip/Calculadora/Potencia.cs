﻿namespace Calculadora
{
    internal class Potencia
    {
        public static double Potenciacao(double valorA, double valorB)
        {
            return Math.Pow(valorA, valorB);
        }
    }
}
