﻿namespace Calculadora
{
    internal class Soma
    {

        public static double Somar(double valorA, double valorB)
        {
            return valorA + valorB;
        }
    }
}
