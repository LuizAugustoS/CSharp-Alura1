﻿namespace Calculadora
{
    internal class RaizQuadrada
    {
        public static double Raiz(double valorA)
        {
            return Math.Sqrt(valorA);
        }
    }
}
