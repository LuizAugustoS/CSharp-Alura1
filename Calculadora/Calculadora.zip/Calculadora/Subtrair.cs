﻿

namespace Calculadora
{
    internal class Subtrair
    {


        public static double Subtracao(double valorA, double valorB)
        {
            return valorA - valorB;
        }
    }
}
