﻿namespace Calculadora
{
    internal class Dividir
    {
        public static double Divisao(double valorA, double valorB)
        {
            return valorA / valorB;
        }
    }
}
