﻿namespace Calculadora
{
    internal class Multiplicar
    {
        public static double Multiplicacao(double valorA, double valorB)
        {
            return valorA * valorB;
        }
    }
}
